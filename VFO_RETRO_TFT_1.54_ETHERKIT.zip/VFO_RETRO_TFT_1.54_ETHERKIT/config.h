/*
 *	"config.h"
 *
 *	"config.h" contains almost everything that a user might want to (or need 
 *	to modify). This includes turning hardware options on or off and defining
 *	different ways those options can be implemented.
 *
 *	It also contains many options that allow a user to customize the apearance
 *	and behavior of the display.
 *
 *	The settings in here are those for my Swan-250C. All of the options are thoroughly
 *	explained in the "ESP32 VFO Hacker's Guide".
 */

#ifndef _CONFIG_H_			// Prevent double inclusion
#define _CONFIG_H_

#include "VFO_defs.h"		// Stuff the user shouldn't mess with!


/*
 *	Define the serial port speed
 */

#define	BIT_RATE 9600

/*-----------------------------------------------------------------------------
        NodeMCU-ESP32 or DevKitC button connections
-----------------------------------------------------------------------------*/
#define STORE 32      //PUSH BUTTON
#define MEMORY_CH 25  //PUSH BUTTON
#define STEP_PLUS 26  //PUSH BUTTON
#define STEP_MINUS 27 //PUSH BUTTON
#define LIMIT 34      //Latching PB to toggle between whether or not to limit frequency to the HAM bands.

#define LED_BUILTIN 2
#define TX 19           //TX output signal high; RX signal LOW
#define DT 13           //Rotary encoder
#define CLK 14          //Rotary encoder

#define BAND_SWITCH  CAT_CONTROL		// Currently using CAT control only
#define MODE_SWITCH  CAT_CONTROL		// Currently using CAT control only


#define PTT_PIN	 4						// Define the GPIO pin number


//#define	DISP_SIZE	CUSTOM_DISP			// Custom display currently in use



/*
 *	Things related to the frequency encoder; note, if either of the encoders seem
 *	to work backwards simply flip-flop the pin "A" and "B" numbers.
 */

#define FREQ_ENCDR_A	13			// Frequency Encoder A
#define FREQ_ENCDR_B	14			// Frequency Encoder B

/*
 *	Define strings used for startup splash screen. Here's the deal: horizontal
 *	position of each line is hard-coded in the "PaintSplash()" function in the
 *	"display.cpp" file.
 *
 *	The font sizes are determined by the "DISP_SIZE".
 *
 *	If you want to eliminate a line, simply define it as "".
 *
 *	If you change the string lengths, you're going to have to play with the "X"
 *	values in the "disp_str" function calls in "PaintSplash()" to keep things centered.
 *	I'm working on a solution for this issue.
 */

#define SPLASH_1	"VFO System"
#define	SPLASH_2	"Version 2.3"
#define	SPLASH_3	"Original:  JF3HZB" 
#define	SPLASH_4	"Modified:  AC9NM"

/*
 *	The following items are all related to customizing the appearance of the display.
 *
 *	The first group of items is NOT dependent on the display size but rather just 
 *	indicate whether or not certain parts of the display should be shown.
 */

#define		PAINT_BOX	    true		// Paint the frequency box if "true"; don't paint it if false
#define		PAINT_VFO_A	    false		// Paint the VFO-A frequency or not
#define		PAINT_VFO_B	    true  		// Paint the VFO-B frequency or not
#define		PAINT_MODE	    true		// Paint the mode indicator or not
#define		PAINT_SPLIT	    false		// Paint the split mode indicator or not
#define		PAINT_UL	    true		// Underline active frequency increment digit for VFO-A
#define		TFT_MODE        0			// Should be 0 or 2 (both landscape)


#define DISP_W	  240		// Display width (in landscape mode)
#define DISP_H	  240 		// Display height (not full height)

#define	BOX_X	   28 		// Left side 'X' coordinate
#define	BOX_Y	   10		// Bottom 'Y' coordinate
#define	BOX_W	  184		// Width of box
#define	BOX_H	   35		// Height of box

	
/*
 *	The display locations of the numerical frequency itself, the clarifier status
 *	indicator, mode indicator and the "Tx/Rx" indicator are all positioned relative
 *	to the location of the frequency box, so they need not be re-located based on the
 *	display size. They will follow the box.
 */

#define	VFO_A_X		BOX_X + 22			// Relative to the box location
#define	VFO_A_Y		BOX_Y + 2

#define	VFO_B_X		BOX_X + 2			// Relative to the box location
#define	VFO_B_Y		BOX_Y + 8

#define	TR_X		BOX_X  + 8			// "X" location
#define	TR_Y		VFO_A_Y + 2			// Same as "MHz"

#define	MODE_X		10					// Top left hand corner of screen
#define	MODE_Y		DISP_H - 15

#define	CLAR_X		DISP_W / 2	 		// Top center of screen
#define	CLAR_Y		DISP_H - 15

#define	SPLIT_X		DISP_W - 50			// Top right hand corner of screen
#define	SPLIT_Y		DISP_H - 15

#define	BATT_X		10			        // Bottom left of screen
#define	BATT_Y		3

#define	D_HEIGHT	200		            // Vertical location of the dial
#define	D_R			200 	            // Dial radius (if 45000, Linear scale)
#define	DIAL_FONT	2			        // Font -  0, 1, or 2 (Defaults to '0' in "dial.cpp")
#define	DIAL_SPACE  45		            // Number of pixels between the main and sub arcs

#define	DP_WIDTH	2				    // Width of Dial pointer
#define	DP_LEN		85			        // Length of Dial pointer
#define	DP_POS		2				    // Position of Dial pointer

#define	SPLASH_Y1	130				    // 'Y' Coordinate of line 1 of the splash screen
#define	SPLASH_Y2	90				    // 'Y' Coordinate of line 2 of the splash screen
#define	SPLASH_Y3	50				    // 'Y' Coordinate of line 3 of the splash screen
#define	SPLASH_Y4	30				    // 'Y' Coordinate of line 4 of the splash screen


/*
 *	The following are the things that the user can change to modify the appearance
 *	and/or behavior of the dial itself. They were moved from the original "dial_prm.h"
 *	and "display.h"	files and converted from variables to definitions.
 */

#define		F_REV				 1		// Frequency increases CW if '1'; CCW (ACW) if '0'

#define		F_MAINTICK1			 1		// Main Tick(1) display on/off
#define		F_MAINTICK5			 1		// Main Tick(5) display on/off
#define		F_MAINTICK10		 1		// Main Tick(10) display on/off
#define		F_MAINNUM			 1		// Main Number display on/off

					// Sub-dial is enabled

#define	F_MAIN_OUTSIDE	1			// 0 - Main dial is inside;  1 - Main dial is outside
#define	F_SUBTICK1      1			// Sub Tick(1) display on/off
#define	F_SUBTICK5      1			// Sub Tick(5) display on/off
#define	F_SUBTICK10     1			// Sub Tick(10) display on/off
#define	F_SUBNUM        1			// Sub Number display on/off


/*
 *	Changing this to anything other than "10000" does weird things with the
 *	displayed numerical values on both dial scales. Still needs to be investigated.
 */

#define		FREQ_TICK_MAIN	 10000		// Tick labels on main dial (if 10000: 10kHz / else： 100kHz)

#define		TICK_PITCH_MAIN		80 		// Main Tick Pitch
#define		TICK_PITCH_SUB		80		// Sub Tick Pitch

#define		TICK_WIDTH			1		// Width of Tick ( 0 or 1 )
#define		TICK_MAIN1			4		// Length of Main Tick(1)
#define		TICK_MAIN5			9		// Length of Main Tick(5)
#define		TICK_MAIN10			12		// Length of Main Tick(10)

#define		TICK_SUB1			8		// Length of Sub Tick(1)
#define		TICK_SUB5			11		// Length of Sub Tick(5)
#define		TICK_SUB10			15		// Length of Sub Tick(10)

#define		TNCL_MAIN			13		// Space between Number and Tick (Main)
#define		TNCL_SUB			16		// Space between Number and Tick (Sub)


/*
 *	Let's define some colors that are used to draw things. Feel free to add to the
 *	list. The following link is a handy tool for selecting colors and getting the
 *	numerical color codes in various formats:
 *
 *						https://www.tydac.ch/color/
 *
 *	These definitions are the 24 bit color codes in red, green, blue format.
 */

#define		CL_GREY			0xA0A0A0UL		// Used for the frequency box
#define		CL_BLACK		0x000000UL		// Used for backgrounds
#define		CL_WHITE		0xFFFFFFUL		// Main dial numbers
#define		CL_RED			0xFF0000UL		// Dial pointer and status indicators
#define		CL_GREEN		0x00FF00UL		// Main dial ticks
#define		CL_LT_BLUE	    0x00FFFFUL		// Sub-dial tick marks
#define		CL_ORANGE		0xFFD080UL		// Numerical frequency display


/*
 *	The following list associates the various components of the display with the
 *	colors we want them to be display as.
 */

#define		CL_BG			CL_BLACK		// Display background (Black)
#define		CL_POINTER		CL_RED			// Dial pointer (Red)
#define		CL_TICK_MAIN	CL_GREEN		// Main Ticks (Lime green)
#define		CL_NUM_MAIN		CL_WHITE		// Main dial numbers (White)
#define		CL_TICK_SUB		CL_LT_BLUE		// Sub Ticks (Light blue)
#define		CL_NUM_SUB		CL_WHITE		// Sub Numbers (White)
#define		CL_DIAL_BG		CL_BLACK		// Dial background (Black)
#define		CL_SPLASH		CL_LT_BLUE		// Splash screen text
#define		CL_FREQ_BOX		CL_GREY			// Numerical frequency box
#define		CL_FA_NUM		CL_ORANGE		// Numerical VFO-A frequency
#define		CL_FB_NUM		CL_ORANGE		// Numerical VFO-B frequency


/*
 *	These 2 are used for the clarifier Tx/Rx and split mode status indicators.
 *	When something is off (inactive) it is displayed in green and when on it is
 *	red. If receiving, the Tx/Rx status is green and red when transmitting.
 */

#define	CL_ACTIVE			CL_RED			// Item is active
#define	CL_INACTIVE			CL_GREEN		// Not active

#endif
