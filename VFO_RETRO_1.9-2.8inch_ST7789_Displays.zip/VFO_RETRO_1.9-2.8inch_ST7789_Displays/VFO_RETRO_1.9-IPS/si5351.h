/* 
 * File:   si5351.h
 * Author: JF3HZB / T.UEBO
 *
 * Created on 2019/02/11, 23:07
 * 
 * AC9NM 2024/12/7
 * Added set_drive_level()
 */


#ifndef __si5351H___
#define __si5351H___
//drive level
#define two_mA    0
#define four_mA   1
#define six_mA    2
#define eight_mA  3

#define clk0 0
#define clk1 1
#define clk2 2

void si5351_init(void);
void set_freq(unsigned long freq);
void set_car_freq(unsigned long freq, unsigned char EN, unsigned char RST);
void cmd_si5351_block(unsigned char reg_No, unsigned char *d);
void set_drive_level(int level, int clk);  // level: 0 = 2mA, 1 = 4mA, 2 = 6mA, 3 = 8mA clk = 0, 1, 2

#endif
