/*
 *	"VFO_defs.h"
 *
 *	"VFO_defs.h" defines the structures for the entries in the "bandData" and "modeData
 *	arrays and symbol values for things that the user should never change. If you do change
 *	anything, you're on your own!
 */

#ifndef _VFO_DEFS_H_			// Prevent double inclusion
#define _VFO_DEFS_H_

#define fmax 160000000       // Max frequency[160 MHz]
#define fmin   100000        // Min frequency[100 KHz]


#define STORE 32      //PUSH BUTTON
#define MEMORY_CH 25  //PUSH BUTTON
#define STEP_PLUS 26  //PUSH BUTTON
#define STEP_MINUS 27 //PUSH BUTTON
#define LIMIT 33      //toggle between whether or not to limit frequency to the HAM bands.
#define LED_BUILTIN 2
#define TX 19         //TX output signal high; RX signal LOW
#define PTT_PIN	 4		// Define the GPIO pin number

// Encoder - Reverse these if encoder count is in wrong direction 
#define CLK 17 // CLK ENCODER 
#define DT 16 // DT ENCODER


/*
 *	Define the structure for "bandData" records:
*/
typedef struct
{
	uint32_t	vfoA;		// VFO-A frequency (receive in split mode)
	uint32_t	lowLimit;	// The lower band edge
	uint32_t	topLimit;	// The upper band edge
	uint8_t		opMode;		// Default mode (subscript to modeData) for this band
} band_data;

/*
 *	Define the structure for "modeData" records:
 */

typedef struct
{
	uint32_t	coFreq;			// Carrier oscillator frequency
	uint8_t		coMode;			// Carrier oscillator mode
	uint8_t		modeSW;			// Mode switch pin number
	uint8_t		catMode;		// Mode selection value used by the "MD" CAT command
	int16_t		vfoAdjust;		// VFO frequency offset to compensate for CO frequency
	char*		modeString;		// String to be displayed on screen
} mode_data;


/*
 *	Define subscripts of the modeData array for modes (assumes the array is in this order):
 */

#define	MODE_LSB	0
#define	MODE_USB	1
#define	MODE_CW		2
#define	MODE_AM		3
#define	MODE_DIG	4


/*
 *	What's up with this? A structure with really one element! All the commented out
 *	flags were holdovers from TJ's original code. They were being set to true or 
 *	false all over the place, but never tested for any reason, thus not needed.
 *
 *	What I did however is left the unused elements in here commented out should they
 *	become needed at some point in the future.
 */


/*
 *	This is a macro that is used to determine the number of elements in an array. It figures
 *	that out by dividing the total size of the array by the size of a single element. This is
 *	how we will calculate the number of entries in the "bandData" array!
 */

#define ELEMENTS(x)		( sizeof ( x ) / sizeof ( x[0] ))


/*
 *	PTT State definitions:
 */

#define	PTT_OFF	HIGH					// PTT_PIN is HIGH when transmitter is off
#define	PTT_ON	LOW						// And LOW when transmitting

#endif
